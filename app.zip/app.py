from root import process_app

if __name__ == '__main__':
    app = process_app()
    app.run(port=80, host='localhost', debug=True)
