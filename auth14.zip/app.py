from root import process_app

if __name__ == '__main__':
    application = process_app()
    application.run(port=80, host='localhost', debug=True)
