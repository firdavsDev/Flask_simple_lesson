import time
from os.path import join as join_path
from pathlib import Path
from urllib.parse import urlparse, urljoin

from flask import request

BASE_PATH = Path(__file__).parent.parent
MEDIA_PATH = join_path(BASE_PATH, 'static')
UPLOAD_PATH = join_path(MEDIA_PATH, 'uploads')
DATA_BASE_URL = join_path(BASE_PATH, 'database', 'db.sqlite')


def new_name(old_name: str):
    ext = old_name.split('.')[-1]
    return '%s.%s' % (time.time_ns(), ext)


def is_safe_url(target):
    ref_url = urlparse(request.host_url)
    test_url = urlparse(urljoin(request.host_url, target))
    return test_url.scheme in ('http', 'https') and ref_url.netloc == test_url.netloc
