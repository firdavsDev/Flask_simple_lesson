from flask_login import UserMixin

from root import db


class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String, nullable=False, unique=True)
    password = db.Column(db.String(300), nullable=False)
    profile_pic = db.Column(db.String, nullable=True)
    is_active = db.Column(db.Boolean, default=False)

    def __repr__(self):
        return self.username

    def __init__(self, _id: int = None,
                 username: str = None,
                 password: str = None,
                 profile_pic: str = None,
                 # email: str = None
                 ):
        self.id = _id
        self.username = username
        self.password = password
        self.profile_pic = profile_pic
        # self.email = email

    def save(self):
        db.session.add(self)
        db.session.commit()
