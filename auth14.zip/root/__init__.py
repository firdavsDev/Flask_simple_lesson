from flask import Flask
from flask_login import LoginManager
from flask_mail import Mail
from flask_migrate import Migrate
from flask_sqlalchemy import SQLAlchemy

from root.utils import DATA_BASE_URL

db = SQLAlchemy()
login_manager = LoginManager()
migrate = Migrate()
mail = Mail()


def process_app():
    application = Flask(__name__)
    from .routers import main, auth
    application.register_blueprint(main)
    application.register_blueprint(auth)
    from root.handlers.error import register_error_handlers
    application.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{DATA_BASE_URL}'
    application.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    application.config['SECRET_KEY'] = 'HELLO_WORLD'
    db.init_app(application)
    # create_table(app)
    login_manager.init_app(application)
    """ERROR HANDLERS"""
    register_error_handlers(app=application)
    """MIGRATION"""
    migrate.init_app(app=application, db=db)

    """MAIL CONF"""

    application.config['MAIL_SERVER'] = 'smtp.mailtrap.io'
    application.config['MAIL_PORT'] = 465
    application.config['MAIL_USERNAME'] = '4c65a37c652f70'
    application.config['MAIL_PASSWORD'] = '3ede487af2e443'
    application.config['MAIL_DEFAULT_SENDER'] = 'john.ldg65@gmail.com'
    application.config['MAIL_USE_TLS'] = False
    application.config['MAIL_USE_SSL'] = True
    mail.init_app(app=application)

    return application

# def create_table(app):
#     db.create_all(app=app)
