from flask import Flask, request
from flask import render_template, url_for, redirect
from flask_login import login_url


def handle_404(error):
    return render_template("errors/404.html", error=error)


def handle_401(error):
    old_path = request.path
    next = login_url(url_for("auth.login"), next_url=old_path)
    return redirect(next)


def register_error_handlers(app: Flask):
    app.register_error_handler(404, handle_404)
    app.register_error_handler(401, handle_401)
