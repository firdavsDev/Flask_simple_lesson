from flask import Blueprint, render_template, request, flash, redirect, url_for, abort
from flask_login import login_required, login_user, current_user, logout_user
from ..utils import UPLOAD_PATH, new_name, is_safe_url
from os.path import join
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
from root import login_manager
from root.database import User

auth = Blueprint('auth', __name__, url_prefix='/auth')


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(user_id)


@auth.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        remember = True if request.form.getlist('remem') else False
        if not user:
            abort(404, {'message': "SOMETHING"})
        if not check_password_hash(user.password, password):
            flash('Bad credentials')
            return redirect(url_for('auth.login'))

        if not login_user(user, remember=remember):
            flash('Bad credentials')
            return redirect(url_for('main.index_page'))

        next = request.args.get("next")
        if not is_safe_url(next):
            abort(400)

        flash('Logged in successfully.')
        return redirect(next or url_for('main.index_page'))
    user = current_user
    return render_template('auth/login.html', user=user)


@auth.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if request.files['profile_img'].filename != '':
            image = request.files['profile_img']
            newname = new_name(image.filename)
            image.save(join(UPLOAD_PATH, secure_filename(newname)))
            password = generate_password_hash(password)
            User(username=username, password=password, profile_pic=newname).save()
            return redirect(url_for('auth.login'))
    return render_template('auth/register.html', user=current_user)


@auth.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("main.index_page"))


@auth.route("/secret")
@login_required
def secret():
    return "SECRET PAGE 😎😎😎😎😎😎"


@auth.route("/secret2")
@login_required
def secret2():
    return "SECRET PAGE 😎😎😎😎😎😎 2 😃"

