import flask
from flask import Blueprint, request
from flask_login import current_user
from flask_mail import Message

from .auth import auth
from .. import mail

main = Blueprint('main', __name__)


@main.route("/")
def index_page():
    user = current_user
    return flask.render_template('home/index.html', user=user)


@main.route("/send_message", methods=['GET', 'POST'])
def message():
    if request.method == 'POST':
        to = request.form['email']
        body = request.form['body']
        msg = Message()
        msg.body = body
        msg.subject = 'Test message'
        msg.sender = 'john.@gmail.com'
        msg.recipients = [to, ]
        mail.send_message(msg)
    return flask.render_template('utils/Message.html', user=current_user)
